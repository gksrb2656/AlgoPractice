# mst
# for tc in range(1,int(input())+1):
#     V, E = map(int, input().split())
#     adj = [[0] * (V + 1) for _ in range(V + 1)]
#     for i in range(E):
#         s, e, c = map(int, input().split())
#         adj[s][e] = c
#         adj[e][s] = c
#
#     INF = float('inf')
#     key = [INF] * (V + 1)
#     p = [-1] * (V + 1)
#     mst = [0] * (V + 1)
#
#     key[0] = 0
#     cnt = 0
#     result = 0
#     while cnt < (V + 1):
#         min = INF
#         u = -1
#         for i in range(V + 1):
#             if not mst[i] and key[i] < min:
#                 min = key[i]
#                 u = i
#         mst[u] = 1
#         result += min
#         cnt += 1
#         for w in range(V + 1):
#             if adj[u][w] > 0 and not mst[w] and key[w] > adj[u][w]:
#                 key[w] = adj[u][w]
#                 p[w] = u
#     print('#{} {}'.format(tc,result))


# mst_prim
# import heapq
# for tc in range(1,int(input())+1):
#     V,E = map(int,input().split())
#     adj = {i:[] for i in range(V+1)}
#     for i in range(E):
#         s,e,c = map(int,input().split())
#         adj[s].append([e,c])
#         adj[e].append([s,c])
#     # print(adj)
#     # key, mst, 우선순위큐 준비
#     INF = float('inf')
#     key = [INF] * (V+1)
#     mst = [0]*(V+1)
#     pq = []
#     # 시작 정점 선택 : 0
#     key[0] = 0
#     # 큐에 모든 정점을 넣음 but 이 코드는 큐에 시작정점만 넣음(key,정점인덱스를 둘 다 넣음)
#     # 우선순위 큐 -> 이진 힙 사용 heapq
#     heapq.heappush(pq,(0,0))  # 우선순위 : 원소의 첫번째 요소인데, 우선순위(가중치=key)에 따라 가져올것(key,정점)
#     result = 0
#     while pq:
#         # 최솟값 찾기
#         k,node = heapq.heappop(pq)
#         if mst[node] : continue
#         # mst로 선택
#         mst[node] = 1
#         result += k
#         # key값 갱신 -> key배열/큐 둘다 갱신
#         for dest,wt in adj[node]:  # dest: 가고싶은 곳, wt: 가중치
#             if not mst[dest] and key[dest]>wt:
#                 key[dest] = wt
#                 # 큐 갱신 -> (key,정점) -> 1. 수정하거나 2. 새로운 (key,정점)을 삽입하고 필요없는 원소는 스킵하거나..
#                 heapq.heappush(pq,(key[dest],dest))
#
#     print('#{} {}'.format(tc,result))


# kruskal
# def make_set(x):
#     p[x] = x
#
# def find_set(x):
#     if p[x] == x: return x
#     return find_set(p[x])
#
# def union(x,y):
#     px= find_set(x)
#     py = find_set(y)
#     if rank[px] > rank[py]:
#         p[py] = px
#     else:
#         p[px] = py
#         if rank[px] == rank[py]:
#             rank[py] += 1
#
# for tc in range(1, int(input())+1):
#     V,E = map(int,input().split())
#     edges = [list(map(int,input().split())) for i in range(E)]
#     # print(edges)
#     # 간선을 간선가중치를 기준으로 정렬
#     edges.sort(key=lambda x:x[2])
#     # print(edges)
#     # MAKE_SET : 모든 정점에 대해 집합 생성
#     p = [0]*(V+1)
#     rank = [0]*(V+1)
#     for i in range(V+1):
#         make_set(i)
#
#     cnt = 0
#     result = 0
#     mst=[]
#     # 모든 간선에 대해서 반복 -> V-1개의 간선이 선택될 때까지
#     for i in range(E):
#         s,e,c = edges[i][0],edges[i][1],edges[i][2]
#         # 사이클이면 스킵 : 간선의 두 정점이 서로 같은 집합이면 -> FIND_SET
#         if find_set(s) == find_set(e) : continue
#         # 간선 선택
#         # -> mst에 간선 정보 더하기 / 두 정점을 합친다 -> UNION
#         result += c
#         mst.append(edges[i])
#         union(s,e)
#         cnt+=1
#         if cnt == V : break
#
#     print('#{} {}'.format(tc,result))
#     # print(mst)


# dijkstra...?
for tc in range(1,int(input())+1):
    V, E = map(int, input().split())
    adj = {i: [] for i in range(V+1)}
    for i in range(E):
        s, e, c = map(int, input().split())
        adj[s].append([e, c])
        adj[e].append([s,c])

    INF = float('inf')
    dist = [INF] * (V+1)
    selected = [0] * (V+1)

    dist[0] = 0
    cnt = 0
    result = 0
    while cnt < (V+1):
        # dist가 최소인 정점 찾기
        min = INF
        u = -1
        for i in range(V+1):
            if not selected[i] and dist[i] < min:
                min = dist[i]
                u = i
        # 결정
        selected[u] = 1
        cnt += 1
        result += min
        # 간선 완화
        for w,cost in adj[u]:         # 도착정점, 가중치
            if not selected[w] and dist[w] > (dist[u]+cost):
                dist[w] = cost
    print('#{} {}'.format(tc,result))